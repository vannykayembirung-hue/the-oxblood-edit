export default function AboutPage() {
  return <section style={{padding:"60px 8%",maxWidth:850,minHeight:"50vh"}}><h1>About The Oxblood Edit</h1><p style={{fontSize:22}}>A luxury editorial system for dark elegance: vamp-romantic fashion, dark beauty rituals and moody interiors.</p><p>Our visual language is built around oxblood, black, parchment cream and antique gold. Intentional, not loud.</p></section>;
}
