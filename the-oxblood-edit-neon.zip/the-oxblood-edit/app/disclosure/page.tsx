export default function DisclosurePage() {
  return <section style={{padding:"60px 8%",maxWidth:850,minHeight:"50vh"}}><h1>Affiliate disclosure</h1><p>Some links may be affiliate links. If a purchase is made through those links, the site may earn a commission at no additional cost to the buyer. Update this disclosure to reflect your actual affiliate relationships and applicable requirements before launch.</p></section>;
}
