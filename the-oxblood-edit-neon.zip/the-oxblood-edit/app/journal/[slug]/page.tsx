import { notFound } from "next/navigation";
import { sql } from "@/lib/db";

export default async function ArticlePage({ params }: { params: { slug: string } }) {
  if (!sql) notFound();
  let article: any;
  try { article = (await sql`select title, excerpt, content_html, category from articles where slug=${params.slug} and status='published' limit 1`)[0]; }
  catch { notFound(); }
  if (!article) notFound();
  return <article style={{padding:"50px 8%",maxWidth:900,margin:"auto",minHeight:"50vh"}}>
    <p style={{textTransform:"uppercase",letterSpacing:".15em"}}>{article.category}</p><h1>{article.title}</h1><p style={{fontSize:22}}>{article.excerpt}</p>
    <div dangerouslySetInnerHTML={{__html: article.content_html || ""}} />
  </article>;
}
