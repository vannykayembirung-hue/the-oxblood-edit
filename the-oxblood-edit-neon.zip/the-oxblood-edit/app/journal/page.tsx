import Link from "next/link";
import { sql } from "@/lib/db";

export default async function JournalPage() {
  let articles: any[] = [];
  if (sql) {
    try { articles = await sql`select slug, title, excerpt, category from articles where status='published' order by created_at desc`; }
    catch (e) { console.error(e); }
  }
  return <section style={{padding:"50px 8%",minHeight:"50vh"}}><h1>Journal</h1><p>Fashion, beauty and interiors for a darker kind of elegance.</p>
    {articles.length ? articles.map((a:any)=><article key={a.slug} style={{padding:"18px 0",borderBottom:"1px solid #C6A15B"}}><small>{a.category}</small><h2>{a.title}</h2><p>{a.excerpt}</p><Link href={`/journal/${a.slug}`}>Read story →</Link></article>) : <p>Editorial stories will appear here when published in the database.</p>}
  </section>;
}
