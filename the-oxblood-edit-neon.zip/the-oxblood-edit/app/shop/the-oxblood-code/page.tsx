import { sql } from "@/lib/db";

export default async function ProductPage() {
  let product: any = null;
  if (sql) {
    try { product = (await sql`select name, price, description, gumroad_url, what_inside from products where slug='the-oxblood-code' limit 1`)[0] || null; }
    catch (e) { console.error(e); }
  }
  const url = product?.gumroad_url && product.gumroad_url !== "__GUMROAD_URL__" ? product.gumroad_url : null;
  return <section style={{padding:"70px 8%",maxWidth:900,minHeight:"50vh"}}>
    <p style={{letterSpacing:".2em",color:"#6E1423"}}>THE SIGNATURE GUIDE</p>
    <h1 style={{fontSize:"clamp(34px,6vw,60px)"}}>{product?.name || "The Oxblood Code"}</h1>
    <p style={{fontSize:24}}>A dark-romantic wardrobe system for timeless, intentional dressing.</p>
    <h2>${product?.price ?? 27} USD</h2>
    <ul>{(product?.what_inside || ["78 pages PDF","12 outfit formulas","Palette #6E1423","US 0-16 / UK 4-20","Printable checklist"]).map((item:string)=><li key={item}>{item}</li>)}</ul>
    {url ? <a className="btn-gold" href={url} target="_blank" rel="noreferrer">GET THE GUIDE</a> : <p><strong>Setup required:</strong> add your real Gumroad URL to the product record in Neon before accepting purchases.</p>}
  </section>;
}
