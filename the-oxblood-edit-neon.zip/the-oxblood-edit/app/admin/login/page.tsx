import { signIn } from "@/lib/auth";

export default function AdminLogin() {
  return <div style={{padding:"60px 8%",maxWidth:560,minHeight:"55vh"}}>
    <h1>Admin sign in</h1>
    <form action={async (formData: FormData) => {
      "use server";
      await signIn("credentials", { email: formData.get("email"), password: formData.get("password"), redirectTo: "/admin" });
    }} style={{display:"grid",gap:14}}>
      <label>Email<input name="email" type="email" required style={{display:"block",width:"100%",padding:12}} /></label>
      <label>Password<input name="password" type="password" required style={{display:"block",width:"100%",padding:12}} /></label>
      <button className="btn-gold" type="submit" style={{border:0,cursor:"pointer"}}>SIGN IN</button>
    </form>
  </div>;
}
