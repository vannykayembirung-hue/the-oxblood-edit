import { sql } from "@/lib/db";

export default async function AdminDashboard() {
  let published = "—";
  let drafts = "—";
  if (sql) {
    try {
      const pub = await sql`select count(*)::int as count from articles where status='published'`;
      const draft = await sql`select count(*)::int as count from articles where status='draft'`;
      published = String(pub[0]?.count ?? 0);
      drafts = String(draft[0]?.count ?? 0);
    } catch (error) {
      console.error("Admin dashboard query failed", error);
    }
  }
  return <div style={{padding:"48px 7%",minHeight:"50vh"}}>
    <h1>Admin dashboard</h1>
    <p>Content overview for The Oxblood Edit.</p>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:18,marginTop:30}}>
      <div style={{background:"white",padding:26,borderTop:"4px solid #C6A15B"}}><p>PUBLISHED</p><strong style={{fontSize:40}}>{published}</strong></div>
      <div style={{background:"white",padding:26,borderTop:"4px solid #6E1423"}}><p>DRAFTS</p><strong style={{fontSize:40}}>{drafts}</strong></div>
    </div>
    <p style={{marginTop:24}}>Starter scaffold: article/product/affiliate editing forms still need implementation before this is a full CMS.</p>
  </div>;
}
